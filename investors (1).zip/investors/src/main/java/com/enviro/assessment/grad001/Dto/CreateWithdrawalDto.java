package com.enviro.assessment.grad001.Dto;

public class CreateWithdrawalDto {
    
    public double amount;
    public String accountNumber;
    public Long product_id;
    
    public Long investor_id;
}
